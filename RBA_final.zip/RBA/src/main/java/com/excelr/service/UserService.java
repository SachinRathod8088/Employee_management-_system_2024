package com.excelr.service;

import com.excelr.DTO.UserDto;
import com.excelr.model.User;

public interface UserService {
	
	User save (UserDto userDto);
	

}
